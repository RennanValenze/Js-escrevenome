function facaCompras(livroA, livroB) {

  let soma = livroA + livroB;
  console.log("A soma dos preços dos livros é: R$ " + soma + ",00");
}

facaCompras(50, 50);
facaCompras(72, 28); 